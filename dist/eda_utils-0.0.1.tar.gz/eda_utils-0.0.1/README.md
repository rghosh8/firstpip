This is my first pip file. the intent of this pip file is to include all the utilities libraries to plot in python

```Python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
